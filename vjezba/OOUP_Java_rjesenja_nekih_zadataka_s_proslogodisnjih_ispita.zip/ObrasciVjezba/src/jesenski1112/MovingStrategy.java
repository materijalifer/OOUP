package jesenski1112;

public interface MovingStrategy {

	public void move();
	
}
