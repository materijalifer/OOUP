package jesenski1112;

public class MoveWithPrediction implements MovingStrategy {

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("Monster moved after predicting player move!");
	}

}
