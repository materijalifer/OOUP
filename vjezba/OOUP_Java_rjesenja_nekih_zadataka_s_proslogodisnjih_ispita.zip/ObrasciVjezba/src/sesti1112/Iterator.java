package sesti1112;

public interface Iterator<T> {
	
	public Integer next();
	public boolean hasNext();
	
}
