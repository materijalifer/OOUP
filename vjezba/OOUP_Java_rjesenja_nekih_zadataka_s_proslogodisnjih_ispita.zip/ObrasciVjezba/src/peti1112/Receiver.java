package peti1112;

public class Receiver {

	public void action(){
		System.out.println("Command reached receiver and is being executed!");
	}
	
}
