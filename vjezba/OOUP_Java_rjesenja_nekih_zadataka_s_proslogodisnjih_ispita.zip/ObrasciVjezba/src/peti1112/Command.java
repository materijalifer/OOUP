package peti1112;

public interface Command {

	public void execute();
	
}
