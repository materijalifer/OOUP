package prvi1011;

public class IspitniProgram {

	public static void main(String[] args) {
		new TheMessageApplication().mainloop();
	}
	
}
