package prvi1011;

public class MessageType1 implements Message{

	@Override
	public void action() {
		// TODO Auto-generated method stub
		System.out.println("Processing message of type MessageType1");
	}

}
