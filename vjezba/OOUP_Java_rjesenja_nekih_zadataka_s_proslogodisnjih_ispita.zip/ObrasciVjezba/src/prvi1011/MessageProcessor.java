package prvi1011;

public interface MessageProcessor {

	public void execute();
	
}
