package prvi1011;

public interface Message {
	
	public void action();

}
