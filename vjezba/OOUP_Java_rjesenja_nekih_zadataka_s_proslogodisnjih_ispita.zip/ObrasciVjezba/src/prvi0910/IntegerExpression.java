package prvi0910;

public interface IntegerExpression {
	public int value();
}
