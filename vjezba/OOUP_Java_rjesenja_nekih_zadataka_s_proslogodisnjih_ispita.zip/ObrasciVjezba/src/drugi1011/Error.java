package drugi1011;

public interface Error {
	public void print();
}
