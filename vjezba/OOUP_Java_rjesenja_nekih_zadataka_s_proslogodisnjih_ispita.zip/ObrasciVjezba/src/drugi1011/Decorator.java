package drugi1011;

public abstract class Decorator implements Error{

	public abstract void print();
	
}
