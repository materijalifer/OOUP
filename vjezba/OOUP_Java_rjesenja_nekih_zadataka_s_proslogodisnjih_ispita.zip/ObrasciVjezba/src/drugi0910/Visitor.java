package drugi0910;

public interface Visitor {
	public void operation(Guest g);
}
