package drugi0910;

public class AgencijaA implements Agencija {

	private String name;
	
	public AgencijaA(String name) {
		// TODO Auto-generated constructor stub
		this.name=name;
	}
	
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	
}
