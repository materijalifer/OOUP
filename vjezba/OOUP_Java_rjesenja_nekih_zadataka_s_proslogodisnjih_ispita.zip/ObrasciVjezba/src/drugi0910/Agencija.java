package drugi0910;

public interface Agencija {

	public String getName();
	
}
