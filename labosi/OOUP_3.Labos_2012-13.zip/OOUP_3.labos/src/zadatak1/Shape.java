package zadatak1;


public interface Shape {
	String id();
	void translate(Point pozicija);
	
}

