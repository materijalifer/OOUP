package zadatak3dodatak;

public class Tea extends Beverage {

	
//	 Čaj se sprema na sličan način:
//	  - zakuhaj vodu
//	  - umetni vrećicu čaja
//	  - izlij u posudu
//	  - dodaj limun	  


	public void brew() {
		System.out.println("Umećemo vrečicu čaja");
	}

	public void addCondiment() {
		System.out.println("Dodajemo limun");
	}

}
