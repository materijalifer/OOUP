package zadatak3;

public class Coffee extends Beverage {

	
//	 Poznato je da se kava radi po sljedećem receptu:
//	  - zakuhaj vodu
//	  - umiješaj kavu
//	  - izlij u posudu
//	  - dodaj šećer i mlijeko


	public void brew() {
		System.out.println("Umiješamo kavu u vodu");
	}

	public void addCondiment() {
		System.out.println("Dodajemo šećer i mlijeko");
	}
	
}
