package hr.fer.ooup.lab3.editor.observer.stack;

public interface StackObserver {

	public void stackEmpty();
	public void stackHasElements();
}
