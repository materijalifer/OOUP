package hr.fer.ooup.lab4.listener;

public interface DocumentModelListener {

	public void documentChanged();
}
