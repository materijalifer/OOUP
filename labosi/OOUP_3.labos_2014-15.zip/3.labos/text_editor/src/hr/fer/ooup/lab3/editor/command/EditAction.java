package hr.fer.ooup.lab3.editor.command;

public interface EditAction {

	public void executeDo();
	public void executeUndo();
}
