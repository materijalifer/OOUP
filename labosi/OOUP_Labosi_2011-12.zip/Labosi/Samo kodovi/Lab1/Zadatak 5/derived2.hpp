#include "base.hpp"

class Derived2 : public Base 
{
    public:
        virtual int solve()
        { 
            return 0;
        }
};