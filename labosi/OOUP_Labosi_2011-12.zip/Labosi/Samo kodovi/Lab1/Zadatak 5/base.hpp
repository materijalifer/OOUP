#pragma once

class Base 
{
    public:
        virtual ~Base() { }
        virtual int solve() = 0;
};