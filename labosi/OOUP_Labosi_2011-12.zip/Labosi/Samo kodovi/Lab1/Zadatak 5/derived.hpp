#include "base.hpp"

class Derived : public Base 
{
    public:
        virtual int solve()
        { 
            return 42;
        }
};