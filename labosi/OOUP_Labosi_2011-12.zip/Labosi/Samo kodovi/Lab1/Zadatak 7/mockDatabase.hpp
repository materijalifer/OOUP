#include "abstractDatabase.hpp"

class MockDatabase : public AbstractDatabase
{
    public:
        void getData()
        {
            // ...
        }
};