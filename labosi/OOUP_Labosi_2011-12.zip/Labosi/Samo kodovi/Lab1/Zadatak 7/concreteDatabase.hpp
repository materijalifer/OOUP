class ConcreteDatabase
{
    public:
        void getData()
        {
            // ...
        }
};