#pragma once

class AbstractDatabase
{
    public:
        virtual void getData() = 0;
};